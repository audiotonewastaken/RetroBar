//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ClassicIEDLL.rc
//
#define IDI_APPICON                     1
#define IDR_CLASSICIEDLL                101
#define IDR_CLASSICIEBHO                102
#define IDB_BITMAP1                     201
#define IDB_GLOW                        201
#define IDS_APP_TITLE                   5000
#define IDS_SETTINGS_TITLE              5001
#define IDS_SETTINGS_TITLE_VER          5002
#define IDS_NEW_SETTINGS                5003
#define IDS_TITLE_SETTINGS              5004
#define IDS_SHOW_CAPTION                5005
#define IDS_SHOW_CAPTION_TIP            5006
#define IDS_CENTER_CAPTION              5007
#define IDS_CENTER_CAPTION_TIP          5008
#define IDS_LANGUAGE_SETTINGS           5009
#define IDS_CAPTION_FONT                5010
#define IDS_CAPTION_FONT_TIP            5011
#define IDS_TEXT_COLOR                  5012
#define IDS_TEXT_COLOR_TIP              5013
#define IDS_MAXTEXT_COLOR               5014
#define IDS_MAXTEXT_COLOR_TIP           5015
#define IDS_INTEXT_COLOR                5016
#define IDS_INTEXT_COLOR_TIP            5017
#define IDS_MAXINTEXT_COLOR             5018
#define IDS_MAXINTEXT_COLOR_TIP         5019
#define IDS_GLOW                        5020
#define IDS_GLOW_TIP                    5021
#define IDS_GLOW_COLOR                  5022
#define IDS_GLOW_COLOR_TIP              5023
#define IDS_MAXGLOW                     5024
#define IDS_MAXGLOW_TIP                 5025
#define IDS_MAXGLOW_COLOR               5026
#define IDS_MAXGLOW_COLOR_TIP           5027
#define IDS_STATUS_SETTINGS             5028
#define IDS_SHOW_PROGRESS               5029
#define IDS_SHOW_PROGRESS_TIP           5030
#define IDS_SHOW_ZONE                   5031
#define IDS_SHOW_ZONE_TIP               5032
#define IDS_SHOW_PROTECTED              5033
#define IDS_SHOW_PROTECTED_TIP          5034
#define IDS_SHOW_ICON                   5035
#define IDS_SHOW_ICON_TIP               5036

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        202
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
